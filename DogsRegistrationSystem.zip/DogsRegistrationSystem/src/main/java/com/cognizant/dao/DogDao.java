package com.cognizant.dao;

import java.util.List;


import org.springframework.stereotype.Service;

import com.cognizant.model.Dogs;

@Service
public interface DogDao {

	public void addDog(Dogs dogs);
	public List<Dogs> getAllDogs();
	public Dogs getDogById(int id);
	public void updateDog(Dogs dogs);
	public void deleteDog(int dogId);
	public Dogs validateDog(Dogs dogs);
}
