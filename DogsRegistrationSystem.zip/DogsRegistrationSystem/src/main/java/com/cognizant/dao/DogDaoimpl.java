package com.cognizant.dao;

import java.util.List;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.model.Dogs;
import com.cognizant.repository.DogRepository;


@Service
public class DogDaoimpl implements DogDao {

	@Autowired
	DogRepository DogRepository;
	
	
	@Override
	public void addDog(Dogs dogs) {
		// TODO Auto-generated method stub
		DogRepository.save(dogs);
	}

	@Override
	public List<Dogs> getAllDogs() {
		// TODO Auto-generated method stub
		List<Dogs> studentList =  DogRepository.findAll();
		return studentList;
		
	}

	@Override
	public Dogs getDogById(int dogId) {
		// TODO Auto-generated method stub
		Dogs dogs = DogRepository.getById(dogId);
		
		return dogs;
	}

	@Override
	public void updateDog(Dogs dogs) {
		// TODO Auto-generated method stub
		DogRepository.save(dogs);
	}

	@Override
	public void deleteDog(int dogId) {
		// TODO Auto-generated method stub
		DogRepository.deleteById(dogId);
	}

	@Override
	public Dogs validateDog(Dogs dogs) {
		// TODO Auto-generated method stub
		Dogs student1 = DogRepository.findByLoginData(dogs.getdName(), dogs.getdPassword());
		return student1;
	}

}
