package com.cognizant.model;


import java.util.Arrays;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.stereotype.Component;

@Entity
@Table(name = "Dogs_info")
@Component
public class Dogs {
	@Id   
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer dogId;
	private String dName;
	private String dPassword;
	private Integer dAge;
	private String ownerEmail;
	private String ownerPhNo;
	private String dBreed;
	private String dCatageory;
	private String dGender;
	private String[] dVstatus; 
	@Lob
	private byte[] dogPic;
	
	public Dogs() {
		super();
	}

	public Dogs(Integer dogId, String dName, String dPassword, Integer dAge, String ownerEmail, String ownerPhNo,
			String dBreed, String dCatageory, String dGender, String[] dVstatus, byte[] studentPic) {
		super();
		this.dogId = dogId;
		this.dName = dName;
		this.dPassword = dPassword;
		this.dAge = dAge;
		this.ownerEmail = ownerEmail;
		this.ownerPhNo = ownerPhNo;
		this.dBreed = dBreed;
		this.dCatageory = dCatageory;
		this.dGender = dGender;
		this.dVstatus = dVstatus;
		this.dogPic = studentPic;
	}

	public Integer getDogId() {
		return dogId;
	}

	public void setDogId(Integer dogId) {
		this.dogId = dogId;
	}

	public String getdName() {
		return dName;
	}

	public void setdName(String dName) {
		this.dName = dName;
	}

	public String getdPassword() {
		return dPassword;
	}

	public void setdPassword(String dPassword) {
		this.dPassword = dPassword;
	}

	public Integer getdAge() {
		return dAge;
	}

	public void setdAge(Integer dAge) {
		this.dAge = dAge;
	}

	public String getOwnerEmail() {
		return ownerEmail;
	}

	public void setOwnerEmail(String ownerEmail) {
		this.ownerEmail = ownerEmail;
	}

	public String getOwnerPhNo() {
		return ownerPhNo;
	}

	public void setOwnerPhNo(String ownerPhNo) {
		this.ownerPhNo = ownerPhNo;
	}

	public String getdBreed() {
		return dBreed;
	}

	public void setdBreed(String dBreed) {
		this.dBreed = dBreed;
	}

	public String getdCatageory() {
		return dCatageory;
	}

	public void setdCatageory(String dCatageory) {
		this.dCatageory = dCatageory;
	}

	public String getdGender() {
		return dGender;
	}

	public void setdGender(String dGender) {
		this.dGender = dGender;
	}

	public String[] getdVstatus() {
		return dVstatus;
	}

	public void setdVstatus(String[] dVstatus) {
		this.dVstatus = dVstatus;
	}

	public byte[] getDogPic() {
		return dogPic;
	}

	public void setDogPic(byte[] studentPic) {
		this.dogPic = studentPic;
	}

	@Override
	public String toString() {
		return "Dogs [dogId=" + dogId + ", dName=" + dName + ", dPassword=" + dPassword + ", dAge=" + dAge
				+ ", ownerEmail=" + ownerEmail + ", ownerPhNo=" + ownerPhNo + ", dBreed=" + dBreed + ", dCatageory="
				+ dCatageory + ", dGender=" + dGender + ", dVstatus=" + Arrays.toString(dVstatus) + ", studentPic="
				+ Arrays.toString(dogPic) + "]";
	}
	
	

}
